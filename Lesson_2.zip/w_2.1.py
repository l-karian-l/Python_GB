# 2.1

list_1 = [10, 1.3, "Nona", 'c']

for i in list:
    print(type(i))